#include <iostream>
#include <utility>
#include <string>
#include "textdisplay.h"

using namespace std;

TextDisplay::TextDisplay() {
	criteria = vector<string> (numCriteria);
	goals = vector<string> (numGoals);
	tiles = vector<TileInfo> (numTiles);
}

void TextDisplay::setCriteria(string pos, int index){
	criteria[index] = pos;
}

void TextDisplay::setGoals(string pos, int index){
	goals[index] = pos;
}

void TextDisplay::setTiles(string posn, char resource, string val, bool isGoose, int index){
	TileInfo ti {posn, resource , val , isGoose};
	tiles[index] = ti;
}


TextDisplay::~TextDisplay() {}


Type TextDisplay::getType() const {
  return Type::Display;
}

void TextDisplay::notify(Subject &whoNotified) {
	/*
	if(whoNotified.getType() == Type::Criterion){
		criteria[whoNotified.getPosn()] = whoNotified.repres();
	}
	*/
}


ostream &operator<<(ostream &out, TextDisplay &td) {
	td.draw(out);
	return out;
}
	

void TextDisplay::resourceString (char c, ostream &out){
	if (c == 'C'){
		out << "/" << "     Caffeine   " << "\\" ;		
	}else if (c == 'L'){
		out << "/" << "       Lab      " << "\\";
	}else if (c == 'S'){
		out << "/" << "      Study     " << "\\";
	}else if(c == 'l'){
		out << "/" << "      Lecture   " << "\\";
	}else if (c == 'N'){
		out << "/" << "      Netflix   " << "\\";
	}else if (c == 'T'){
		out << "/" << "     Tutorial   " << "\\";
	}
}

void TextDisplay::addSpace(int x, ostream &out){
	for (int i = 0; i < x; i++){
		out << " ";
	}
}

void TextDisplay::addthreeVals (string x, string y, string z, ostream &out){
	if (x.length() > 1){
		out << "|" << x << "|";
	}else{
		out << "| " << x << "|";
	}

	if (y.length() > 1 ){
		out << "--" << y << "--";
	}else{
		out << "-- " << y << "--";
	}

	if (z.length() > 1){
		out << "|" << z << "|";
	}else{
		out << "| " << z << "|";
	}
}

void TextDisplay::addValue(string x,ostream &out){
	if (x.length() > 1){
		out << "       " << x << "       ";
	}else if (x == "7"){
		out << "        " << " " << "       ";
	}else{
		out << "        " << x << "       ";
	}
}

void TextDisplay::addSlash(ostream &out){
	out << "/" << "            " << "\\";
}

void TextDisplay::addTileNumber(string x, string y, string z,ostream &out){
	if (x.length() > 1){
		if (y.length() > 1){
			out << x << "     " << y;	
		}else{
			out << x << "      " << y;
		}		
	}else{
		if (y.length() > 1){
			out << x << "      " << y;	
		}else{
			out << x << "       " << y;
		}		
	}

	if (z.length() > 1){
		out << "     " << z;
	}else{
		out << "      " << z;
	}
}

void TextDisplay::addGeese(bool geese,ostream &out){
	if (!geese){
		out << "                ";
	}else{
		out << "      Geese     ";
	}
}

void TextDisplay::addSingle(string x,ostream &out){
	if (x.length() > 1){
		out << "|" << x << "|";
	}else{
		out << "| " << x << "|";
	}
}

void TextDisplay::draw(ostream & out) {
	//Line 1
	addSpace(37, out);
	addthreeVals(criteria[0], goals[0], criteria[1], out);
	out << endl;

	//Line 2
	addSpace(37, out);
	addSlash(out);
	out << endl;

	//Line 3
	addSpace(36, out);
	addTileNumber(goals[1], tiles[0].posn, goals[2], out);
	out <<endl;

	//Line 4
	addSpace(35, out);
	resourceString(tiles[0].resource, out);
	out << endl;
	
	//Line 5
	addSpace(22, out);
	addthreeVals(criteria[2], goals[3], criteria[3], out);
	addValue(tiles[0].val, out);
	addthreeVals(criteria[4], goals[4], criteria[5], out);
	out << endl;

	//Line 6
	addSpace(22, out);
	addSlash(out);
	addGeese(tiles[0].isGoose, out);	
	addSlash(out);
	out << endl;

	//Line 7
	addSpace(21, out);
	addTileNumber(goals[5], tiles[1].posn, goals[6], out);
	addSpace(14, out);
	addTileNumber(goals[7], tiles[2].posn, goals[8], out);
	out<< endl;


	//Line 8
	addSpace(20, out);
	resourceString(tiles[1].resource, out);
	addSpace(12, out);
	resourceString(tiles[2].resource, out);
	out <<endl;

	//Line 9
	addSpace(7, out);
	addthreeVals(criteria[6], goals[9], criteria[7], out);
	addValue(tiles[1].val, out);
	addthreeVals(criteria[8], goals[10], criteria[9], out);
	addValue(tiles[2].val, out);
	addthreeVals(criteria[10], goals[11], criteria[11], out);
	out << endl;

	//Line 10
	addSpace(7, out);
	addSlash(out);
	addGeese(tiles[1].isGoose, out);
	addSlash(out);
	addGeese(tiles[2].isGoose, out);
	addSlash(out);
	out <<endl;

	//Line 11
	addSpace(6, out);
	addTileNumber(goals[12], tiles[3].posn, goals[13], out);
	addSpace(14, out);
	addTileNumber(goals[14], tiles[4].posn, goals[15], out);
	addSpace(14, out);
	addTileNumber(goals[16], tiles[5].posn, goals[17], out);
	out <<endl;

	//Line 12
	addSpace(5, out);
	resourceString(tiles[3].resource, out);
	addSpace(12, out);
	resourceString(tiles[4].resource, out);
	addSpace(12, out);
	resourceString(tiles[5].resource, out);
	out<<endl;

	//Line 13
	addSpace(2, out);
	addSingle(criteria[12], out);
	addValue(tiles[3].val, out);
	addthreeVals(criteria[13], goals[18], criteria[14], out);
	addValue(tiles[4].val, out);
	addthreeVals(criteria[15], goals[19], criteria[16], out);
	addValue(tiles[5].val, out);
	addSingle(criteria[17], out);
	out<<endl;

	//Line 14
	addSpace(5, out);
	out << "\\";
	addGeese(tiles[3].isGoose, out);
	addSlash(out);
	addGeese(tiles[4].isGoose, out);
	addSlash(out);
	addGeese(tiles[5].isGoose, out);
	out << "/";
	out << endl;

	//Line 15
	addSpace(5, out);
	out << goals[20];
	addSpace(14, out);
	addTileNumber(goals[21], tiles[6].posn, goals[22], out);
	addSpace(14, out);
	addTileNumber(goals[23], tiles[7].posn, goals[24], out);
	addSpace(14, out);
	out << goals[25];
	out << endl;

	//Line 16
	addSpace(7, out);
	out << "\\";
	addSpace(12, out);
	resourceString(tiles[6].resource, out);
	addSpace(12, out);
	resourceString(tiles[7].resource, out);
	addSpace(12, out);
	out << "/";
	out << endl;

	// Line 17
	addSpace(7, out);
	addthreeVals(criteria[18], goals[26], criteria[19], out);
	addValue(tiles[6].val, out);
	addthreeVals(criteria[20], goals[27], criteria[21], out);
	addValue(tiles[7].val, out);
	addthreeVals(criteria[22], goals[28], criteria[23], out);
	out << endl;

	//Line 18
	addSpace(7, out);
	addSlash(out);
	addGeese(tiles[6].isGoose, out);
	addSlash(out);
	addGeese(tiles[7].isGoose, out);
	addSlash(out);
	out <<endl;

	//Line 19
	addSpace(6, out);
	addTileNumber(goals[29], tiles[8].posn, goals[30], out);
	addSpace(14, out);
	addTileNumber(goals[31], tiles[9].posn, goals[32], out);
	addSpace(14, out);
	addTileNumber(goals[33], tiles[10].posn, goals[34], out);
	out <<endl;

	//Line 20
	addSpace(5, out);
	resourceString(tiles[8].resource, out);
	addSpace(12, out);
	resourceString(tiles[9].resource, out);
	addSpace(12, out);
	resourceString(tiles[10].resource, out);
	out<<endl;

	//Line 21
	addSpace(2, out);
	addSingle(criteria[24], out);
	addValue(tiles[8].val, out);
	addthreeVals(criteria[25], goals[35], criteria[26], out);
	addValue(tiles[9].val, out);
	addthreeVals(criteria[27], goals[36], criteria[28], out);
	addValue(tiles[10].val, out);
	addSingle(criteria[29], out);
	out<<endl;

	//Line 22
	addSpace(5, out);
	out << "\\";
	addGeese(tiles[8].isGoose, out);
	addSlash(out);
	addGeese(tiles[9].isGoose, out);
	addSlash(out);
	addGeese(tiles[10].isGoose, out);
	out << "/";
	out << endl;

	//Line 23
	addSpace(5, out);
	out << goals[37];
	addSpace(14, out);
	addTileNumber(goals[38], tiles[11].posn, goals[39], out);
	addSpace(14, out);
	addTileNumber(goals[40], tiles[12].posn, goals[41], out);
	addSpace(14, out);
	out << goals[42];
	out << endl;

	//Line 24
	addSpace(7, out);
	out << "\\";
	addSpace(12, out);
	resourceString(tiles[11].resource, out);
	addSpace(12, out);
	resourceString(tiles[12].resource, out);
	addSpace(12, out);
	out << "/";
	out << endl;

	//Line 25
	addSpace(7, out);
	addthreeVals(criteria[30], goals[43], criteria[31], out);
	addValue(tiles[11].val, out);
	addthreeVals(criteria[32], goals[44], criteria[33], out);
	addValue(tiles[12].val, out);
	addthreeVals(criteria[34], goals[45], criteria[35], out);
	out << endl;

	//Line 26
	addSpace(7, out);
	addSlash(out);
	addGeese(tiles[11].isGoose, out);
	addSlash(out);
	addGeese(tiles[12].isGoose, out);
	addSlash(out);
	out <<endl;

	//Line 27
	addSpace(6, out);
	addTileNumber(goals[46], tiles[13].posn, goals[47], out);
	addSpace(14, out);
	addTileNumber(goals[48], tiles[14].posn, goals[49], out);
	addSpace(14, out);
	addTileNumber(goals[50], tiles[15].posn, goals[51], out);
	out <<endl;

	//Line 28
	addSpace(5, out);
	resourceString(tiles[13].resource, out);
	addSpace(12, out);
	resourceString(tiles[14].resource, out);
	addSpace(12, out);
	resourceString(tiles[15].resource, out);
	out<<endl;

	//Line 29
	addSpace(2, out);
	addSingle(criteria[36], out);
	addValue(tiles[13].val, out);
	addthreeVals(criteria[37], goals[52], criteria[38], out);
	addValue(tiles[14].val, out);
	addthreeVals(criteria[39], goals[53], criteria[40], out);
	addValue(tiles[15].val, out);
	addSingle(criteria[41], out);
	out<<endl;

	//Line 30
	addSpace(5, out);
	out << "\\";
	addGeese(tiles[13].isGoose, out);
	addSlash(out);
	addGeese(tiles[14].isGoose, out);
	addSlash(out);
	addGeese(tiles[15].isGoose, out);
	out << "/";
	out << endl;

	//Line 31
	addSpace(5, out);
	out << goals[54];
	addSpace(14, out);
	addTileNumber(goals[55], tiles[16].posn, goals[56], out);
	addSpace(14, out);
	addTileNumber(goals[57], tiles[17].posn, goals[58], out);
	addSpace(14, out);
	out << goals[59];
	out << endl;

	//Line 32
	addSpace(7, out);
	out << "\\";
	addSpace(12, out);
	resourceString(tiles[16].resource, out);
	addSpace(12, out);
	resourceString(tiles[17].resource, out);
	addSpace(12, out);
	out << "/";
	out << endl;

	//Line 33
	addSpace(7, out);
	addthreeVals(criteria[42], goals[60], criteria[43], out);
	addValue(tiles[16].val, out);
	addthreeVals(criteria[44], goals[61], criteria[45], out);
	addValue(tiles[17].val, out);
	addthreeVals(criteria[46], goals[62], criteria[47], out);
	out << endl;

	//Line 34
	addSpace(20, out);
	out << "\\";
	addGeese(tiles[16].isGoose, out);
	addSlash(out);
	addGeese(tiles[17].isGoose, out);
	out << "/";
	out << endl;

	//Line 35
	addSpace (21, out);
	out << goals[63];
	addSpace(14, out);
	addTileNumber(goals[64], tiles[18].posn, goals[65], out);
	addSpace(14, out);
	out << goals[66];
	out << endl;

	//Line 36
	addSpace(22, out);
	out << "\\";
	addSpace(12, out);
	resourceString(tiles[18].resource, out);
	addSpace(12, out);
	out << '/';
	out << endl;

	//Line 37
	addSpace(22, out);
	addthreeVals(criteria[48], goals[67], criteria[49], out);
	addValue(tiles[18].val, out);
	addthreeVals(criteria[50], goals[68], criteria[51], out);
	out << endl;

	//Line 38
	addSpace(35, out);
	out << "\\";
	addGeese(tiles[18].isGoose, out);
	out << "/";
	out <<endl;

	//Line 39
	addSpace(35, out);
	out << goals[69];
	addSpace(14, out);
	out << goals[70];
	out << endl;

	//Line 40
	addSpace(37, out);
	out << "\\";
	addSpace(12, out);
	out << "/";
	out << endl;

	//Line 41
	addSpace(37, out);
	addthreeVals(criteria[52], goals[71], criteria[53], out);
	out << endl;

}



