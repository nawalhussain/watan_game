#include <cstdlib>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <string.h>
#include <cstdlib>

#include "game.h"
#include "player.h"
#include "criterion.h"
#include <string>
#include "goal.h"
#include "tile.h"
#include "board.h"


using namespace std;

string cantBuild(){
	return "You cannot build here";
}

string invalid(){
	return "Invalid Command.";
}

int main(int argc, char** argv) {
	cin.exceptions(ios::eofbit|ios::failbit);
	bool fileLoaded = false;
	bool boardLoaded = false;
	string cmd;
	Game g;
	int currTurn = 0;
	// Parsing command line argument
	stringstream ss;
	int see;
	string loadFile, boardFile;
	int i = 0;

	while(i < argc - 1){
		if (strcmp(argv[i] ,"-seed") == 0){
			ss << argv[i+1];
			ss >> see;  
			g.seed(see); 
			i+=2;
		}
		else if (strcmp(argv[i] ,"-load") == 0){
			loadFile = argv[i+1];
			currTurn = g.load(loadFile);
			i+=2;
			fileLoaded = true;
		}
		else if (strcmp(argv[i] ,"-board") == 0){
			boardFile = argv[i+1];
			g.loadBoard(boardFile);
			boardLoaded = true;
			i+=2;
		}
		else{
			++i;
		}
	}

	if (!fileLoaded && !boardLoaded) g.init();

	try {
		if (!fileLoaded){
			//Pick initial assignments
		    int location;
		    Player * p;
		    bool secondPass = false;
		    int pIndex = 0;
		    while (pIndex >= 0) {
		    	p = g.getPlayer(pIndex);
		    	cout << "Student " << p->getColour() ;
		        cout <<  ", where do you want to complete an Assignment?" << endl;
		        cin >> location;
		        if (p->completeInitial(g.getCriterion(location))){
		        	if (secondPass) --pIndex;
		        	else ++pIndex;
		        }
		        else{
		        	cout << cantBuild() << endl;
		        	continue;
		        }

		        if (pIndex > 3 ){
		        	--pIndex;
		        	secondPass = true;
		        }
		    }	
		}		
	    g.updateDisplay();
	    g.printBoard();
	  	
	    //Taking turns
	    int pInd= currTurn;
	    while (true) {    	
	    	Player * p = g.getPlayer(pInd); 
	    	int diceRoll;

		    cout << "Student " << p->getColour() << "'s turn." << endl;
		    cout << *p;
	        // Rolling the dice
	        while (true){
	            cin >> cmd;
	            if (cmd == "load"){
	            	p->setLoaded(true);
	            }
	            else if (cmd == "fair"){
	            	p->setLoaded(false);
	            }
	            else if (cmd == "roll"){
	                if(p->isLoaded()){
	                	while(true){
	                		cout << "Input a roll between 2 and 12: " << endl;
	                		int r;
	                		cin >> r;
	                		if (r >= 2 && r <= 12){
	                			diceRoll = r;
	                			break;
	                		}
	                		cout << "Invalid Roll" << endl;
	                	}
	                }else{
	                	srand(time(0));
	            		int r1 = rand() % 6 + 1;
	            		srand(r1);
	            		int r2 = rand() % 6 + 1;
	            		diceRoll = r1 + r2;
	                }
	                cout << "A " << diceRoll << " was rolled !" << endl;
	                g.play(diceRoll);
	                break;
	            }
	            else{
	            	cout << invalid() << endl;
	            }
	        } // catch errors here as a roll must be done.

	        // Post roll choices
			while (true){
				cout << "reach command lines"<<endl;
			    cin >> cmd;
			    if (cmd == "board"){
			    	g.updateDisplay();
			    	g.printBoard();
			    }
			    else if (cmd == "status"){
			    	for (int i = 0; i <= 3; ++i){
			    		cout << *(g.getPlayer(i)); 
			    	}
			    }
			    else if (cmd == "criteria"){
			    	p->printOwnedCriteria();
			    }
			    else if (cmd == "achieve"){
		            int goalNum;
		            cin >> goalNum;
		            p->achieve(g.getGoal(goalNum));
			    }
			    else if (cmd == "complete"){
		            int criteriaNum;
		            cin >> criteriaNum;
		            p->complete(g.getCriterion(criteriaNum));
			    }
			    else if (cmd == "improve"){
		            int criteriaNum;
		            cin >> criteriaNum;
		            p->improve(g.getCriterion(criteriaNum));
			    }
			    else if (cmd == "trade"){
		            string colour,give,take;
		            cin >> colour >> give >> take;
		            
			    }
			    else if (cmd == "help"){
			    	cout << "Valid commands:" << endl << "board" << endl;
			    	cout << "status" << endl << "criteria" << endl;
			    	cout << "achieve <goal>" << endl;
			    	cout << "complete <criterion>" << endl;
			    	cout << "improve <criterion>" << endl;
			    	cout << "trade <colour> <give> <take>" << endl;
			    	cout << "next" << endl << "save <file>" << endl;
			    	cout << "help" << endl;
			    }
			    else if (cmd == "save"){
			    	string file;
			    	cin >> file;
			        g.save(pInd,file);
			    }
			    else if (cmd == "next"){
			    	if (pInd == 3) pInd = 0;
			    	else ++pInd ;
			    	break;
		            // next turn
			    }else{
			    	cout << invalid() << endl;
			    }

			    if (p->isWon()) { 
		            string answer;
		            cout << "Would you like to play again?";
		            cin >> answer;
		            if (answer == "yes"){
		            	pInd = 0;
						g.newGame();
		            }
		            else if (answer == "no"){
		                break;  //ggwp
		            }
		        }
			}
		}
	}
	catch (ios::failure &) {
 	}
}
