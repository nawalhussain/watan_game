#include "player.h"
#include "criterion.h"
#include "goal.h"
#include <string>
#include <sstream>

using namespace std;

Player::Player(string colour): colour {colour} , points {0}{
}

Player::~Player() {
}

void Player::setLoaded(bool isload){
	loaded = isload;
}

bool Player::isLoaded(){
	return loaded;
}

string Player::getColour(){
	return colour ;
}

bool Player::isWon(){
	return (points == 10);
}

bool Player::completeInitial(Criterion * c){
	if (c->completeInitial(this)){
		ownedCriteria.emplace_back(c);
		return true;
	}
	return false;
}

bool Player::completeLoaded(Criterion * c, int l){
	if (c->completeLoaded(this, l)){
		ownedCriteria.emplace_back(c);
		// cout << l << endl;
		points += l;
		return true;
	}
	return false;
}

bool Player::complete(Criterion * c){
	if (c->complete(this)){
		ownedCriteria.emplace_back(c);
		points++;
		return true;
	}
	return false;
}

bool Player::improve(Criterion * c){
	if (c->improve(this)){
		points++;
		return true;
	}
	return false;
}

bool Player::achieve(Goal * g){
	if (g->complete(this)){
		ownedGoals.emplace_back(g);
		return true;
	}
	return false;
}

void Player::loadGoals(Goal * g){
	ownedGoals.emplace_back(g);
}

int Player::getPoints(){
	return points;
}

int Player::getResource(char rsrc){
	return resources[rsrc];
}

string Player::saveGoals(){	
 	stringstream ss;
	for (auto goal : ownedGoals){
        ss << goal->getPosn() << " " ;
   	}
   	return ss.str();
}

string Player::saveCriteria(){
    stringstream ss;
	for (auto crit : ownedCriteria){
		ss << crit->getPosn() << " " << crit->getLevel() << " ";
	}
	return ss.str();
}


void Player::printOwnedCriteria() {
	cout << colour << " has completed:" << endl; 
	for (auto crit : ownedCriteria){
		cout << crit->getPosn() << " " << crit->getLevel() << endl;
	}
}

void Player::updateResources(char rsrc, int amount){
	resources[rsrc] += amount;
}

ostream &operator<<(ostream &out, Player &p) {
	out << p.colour << " has " << p.points << " grades, " << p.resources['C'];
	out << " caffeines, " << p.resources['L'] << " labs, " << p.resources['l'];
	out << " lectures, " << p.resources['T'] <<  " tutorials, and ";
	out << p.resources ['S'] << " studies." << endl;
	return out;
}


 


// bool Player::trade(char tradeWith, char give, char take){
	
// }
