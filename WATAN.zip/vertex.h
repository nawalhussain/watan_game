#ifndef _VERTEX_H_
#define _VERTEX_H_

#include "completableboardpiece.h"


class Vertex : public CompletableBoardPiece {
public:
	virtual ~Vertex() = 0;	
};


#endif
