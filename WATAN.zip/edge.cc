#include "edge.h"

Edge::~Edge(){

}

bool Edge::isItHoriz(){
	return isHoriz;
}

void Edge::setIsHoriz(bool b){
	isHoriz = b;
}

