#ifndef TILE_H
#define TILE_H
#include <iostream> 
#include "boardpiece.h"
#include "types.h"

class Criterion;

class Tile : public BoardPiece {
    char resource; // resource on tile
    int rollVal; // value that when rolled activates this tile
    bool isGeese; // keeps track of if this tile has geese on it
    std::string repres;
public:
    Tile();
    virtual ~Tile();
    Type getType() const;
    int checkRoll(int roll); // checks if roll matches rollVal, if it does, notify all non null Criterion
    char getRes(); // returns resource
    int getVal(); // returns rollVal
	bool geeseCheck(); // returns true iff there are geese on this tile
    void setRoll(int roll);
    void setResource(char c);
    std::string getRepres();

    void play();
private:
    friend std::ostream &operator<<(std::ostream &out, const Tile &t);
};



#endif /* TILE_H */
