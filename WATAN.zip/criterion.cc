#include <sstream>
#include "criterion.h"
#include "goal.h"
#include "player.h"
#include "types.h"

using namespace std;

Criterion::Criterion() {
	repres = to_string(this->getPosn());
	setOwner(nullptr);
}

Criterion::~Criterion() {
}

bool Criterion::enoughResources(Player * p){
	if (level == 0) {
		if ((p->getResource('C') >= 1) && (p->getResource('L') >= 1) &&
			(p->getResource('l') >= 1) && (p->getResource('T') >= 1)) {
			return true;
		}
	}else if (level == 1){
		if ((p->getResource('l') >= 2) && (p->getResource('L') >= 3)) {
			return true;
		}
	}else if (level == 2){
		if ((p->getResource('C') >= 3) && (p->getResource('L') >= 2) &&
			(p->getResource('l') >= 1) && (p->getResource('S') >= 1)) {
			return true;
		}
	}
	return false;
}

bool Criterion::isAchievableInitial(){
	// cout << "works here" << endl;
	if (!this->isOwned()) {
		// cout << "works here" << endl;
		for(auto crit : nghbrCriteria){
			if (crit->isOwned()){
				return false;
			}
		}
		return true;
	}
	return false;
}

bool Criterion::completeInitial(Player *p) {
	if (isAchievableInitial()){
		setOwner(p);
		level = 1;
		return true;
	} else{
		return false;
	}
}

bool Criterion::completeLoaded(Player * p, int l){
	// cout << "works here" << endl;
	if (isAchievableInitial()){
		setOwner(p);
		level = l;
		return true;
	}else{
		return false;
	}
}

bool Criterion::isAchievable(Player * p){
	if (!this->isOwned()) {
		for(auto crit : nghbrCriteria){
			if (crit->isOwned()){
				return false;
			}
		}
		for (auto goal : nghbrGoals){
			if (goal->isOwnedBy(p)){
				return true;
			}
		}
		return false;
	}
	return false;
}

bool Criterion::improve(Player *p) {
	if (this->isOwnedBy(p) && level < 3){
		if (enoughResources(p)){
			if (level == 1){
				p->updateResources('l', -2);
				p->updateResources('L', -3);
				++level;
			}
			else if (level == 2){
				p->updateResources('C', -3);
				p->updateResources('L', -2);
				p->updateResources('l', -1);
				p->updateResources('S', -1);
				++level;
			}
			return true;
		}
		cout << "You do not have enough resources." << endl;
		return false;
	}
	cout << "You cannot build here." << endl;
	return false;
}


bool Criterion::complete(Player *p) {
	if (isAchievable(p)) {
		if (enoughResources(p)){
			setOwner(p);
			level = 1;
			p->updateResources('C', -1);
			p->updateResources('L', -1);
			p->updateResources('l', -1);
			p->updateResources('T', -1);
			//repres = p->getColour()[0] + "A";
			return true;
		}
		cout << "You do not have enough resources." << endl;
		return false; 
	}
	cout << "You cannot build here." << endl;
	return false;
}

void Criterion::notify(Subject &whoNotified){
	/*
	if (whoNotified)
	if (isOwned()){
		/////
	}
	*/
}

void Criterion::give(char rsrc){
	if (isOwned()){
		getOwner()->updateResources(rsrc,level);
	}
}


Type Criterion::getType() const {
  return Type::Criterion;
}

string Criterion::getRepres(){
	stringstream ss;
	if (!isOwned()){
		return to_string(getPosn());
	}else{
		ss << getOwner()->getColour()[0] << getLevelChar();
		return ss.str();
	}
}

int Criterion::getLevel(){
	return level;
}

char Criterion::getLevelChar(){
	if (level == 1) return 'A';
	else if (level == 2) return 'M';
	else if (level == 3) return 'F';	
}

