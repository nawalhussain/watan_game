#ifndef PLAYER_H
#define PLAYER_H

#include <map>
#include <vector>
#include <string>

class Criterion;
class Goal;

class Player {
    std::map<char,int> resources; // resource counts
    std::string colour; // colour of this player
    int points; // number of victory points
    bool loaded; // are the dice loaded or not
    std::vector<Criterion*> ownedCriteria; // course criterion owned by this player
    std::vector<Goal*> ownedGoals; // goals achieved by this player
public:
    Player(std::string Colour);
    virtual ~Player();
    std::string getColour();
    void updateResources(char rsrc, int amount);
    int getResource(char rsrc);
    void printOwnedCriteria();
    bool isWon();
    int getPoints();
    void status(); // prints status of player
    
    bool complete(Criterion * c); // attempts to complete criterion at critNum, returns true if successful
    bool completeInitial(Criterion * c);
    bool completeLoaded(Criterion * c, int l);
    bool improve(Criterion * c);
    bool achieve(Goal * g);

    std::string saveGoals();
    std::string saveCriteria();

    void loadGoals(Goal * g);

    void setLoaded(bool isload);
    bool isLoaded();
    bool improve(int critNum); // attempts to improve criterion at critNum, returns true if successful
    void printCrit(); // prints all criterion owned by this player
    bool trade(char tradeWith, char give, char take); // atempts to trade with tradeWith (colour) for one resource of give to get one resource of take. returns true if successful.6
    friend std::ostream &operator<<(std::ostream &out, Player &p);
};

#endif /* PLAYER_H */

