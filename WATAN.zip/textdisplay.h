#ifndef __TEXTDISPLAY_H__
#define __TEXTDISPLAY_H__
#include <iostream>
#include <vector>
#include <string>
#include "types.h"
#include "observer.h"
#include "subject.h"


struct TileInfo {
	std::string posn;
	char resource;
	std::string val;
	bool isGoose;
};

class TextDisplay: public Observer {
	const int numTiles = 19;
    const int numCriteria = 54;
    const int numGoals = 72;
    const int size = 5;  
	std::vector<std::string> criteria;
	std::vector<std::string> goals;
	std::vector<TileInfo> tiles;
public:
	TextDisplay();
	Type getType() const ; //override

	void setCriteria(std::string pos, int index);
   	void setGoals(std::string pos, int index);
    void setTiles(std::string posn, char resource, std::string val, bool isGoose, int index);
	
	void notify(Subject &whoNotified) override;
	~TextDisplay();
	void draw(std::ostream &out) ;
	friend std::ostream &operator<<(std::ostream &out,  TextDisplay &td);

private:
	void addGeese(bool geese,std::ostream &out);
	void addSingle(std::string x,std::ostream &out);
	void addValue(std::string x,std::ostream &out);
	void addSlash(std::ostream &out);
	void addTileNumber(std::string x, std::string y ,std::string z,std::ostream &out);
	void resourceString (char c, std::ostream &out);
	void addSpace(int x, std::ostream &out);
	void addthreeVals (std::string x ,std::string y ,std::string z, std::ostream &out);
};

#endif
