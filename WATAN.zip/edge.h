#ifndef _EDGE_H_
#define _EDGE_H_

#include "completableboardpiece.h"

class Edge : public CompletableBoardPiece {
	bool isHoriz;
public:
	virtual ~Edge() = 0;
	void setIsHoriz(bool b);
	bool isItHoriz();
};

#endif
