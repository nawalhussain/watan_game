#ifndef CRITERION_H
#define CRITERION_H
#include <vector>
#include "types.h"     
#include "vertex.h"


class Goal;
class Player;

class Criterion : public Vertex, public Observer {
	int level = 0; // 1 = assn, 2 = mid, 3 = final
	std::string repres;
public:
    Criterion();
    virtual ~Criterion();
    char getLevelChar();
    int getLevel();
    Type getType() const ; // override
    bool complete (Player *p)  ; //override
    bool completeInitial(Player *p);
    bool completeLoaded(Player * p, int l);
    bool improve (Player * p); // if already completed, upgrades to next level if player has enough resources
    
    void notify(Subject &whoNotified); // notifies owner that this goal gained a resource
    
    std::string getRepres();
    void give(char rsrc);
private:
	bool enoughResources(Player * p);
	bool isAchievableInitial();
	bool isAchievable(Player *p);
};

#endif /* CRITERION_H */

