#include "game.h"
#include "board.h"
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <algorithm>
#include <fstream>

using namespace std;

Game::Game() {
}

Criterion * Game::getCriterion(int pos){
	return b->getCriterionAt(pos);
}

Goal * Game::getGoal(int pos){
	return b->getGoalAt(pos);
}

Player * Game::getPlayer(int i){
	return players[i];
}

void Game::play(int rollNumber){
	b->play(rollNumber);
}

void Game::newGame(){
	delete b;
	for (auto p : players){
		delete p;
	}
	init();
}

Player * Game::getPlayer(string colour){
	if (colour == "Blue"){
		return players[0];
	}
	if (colour == "Red"){
		return players[1];
	}
	if (colour == "Orange"){
		return players[2];
	}
	if (colour == "Yellow"){
		return players[3];
	}
}

Game::~Game() {
	delete b;
	for (auto p : players){
		delete p;
	}
}

void Game::updateDisplay(){
	b->updateDisplay();
}

void Game::printBoard(){
	b->updateDisplay();
	cout << *b;
}


void Game::seed(int see){
	s = see;
}

void Game::loadBoard(string fileName){
	srand(s);
	b = new Board;
	ifstream file {fileName};
    string line,s;
    getline(file, line);
    istringstream iss(line);


	Player * p1 = new Player {"Blue"};
	players.emplace_back(p1);
	Player * p2 = new Player {"Red"};
	players.emplace_back(p2);
	Player * p3 = new Player {"Orange"};
	players.emplace_back(p3);
	Player * p4 = new Player {"Yellow"};
	players.emplace_back(p4);

	int x[19];
	x[0] = 2;
	int counter = 1;
	for (int i = 3; i <= 6; i++){
		x[counter] = i;
		x[counter + 1] = i;
		counter += 2;
	}
	for (int i = 8; i <= 11; i++){
		x[counter] = i;
		x[counter + 1] = i;
		counter += 2;
	}
	x[counter] = 12;
	x[counter + 1] = 7;
	random_shuffle(&x[0], &x[19]);

	int num;

	for (int i = 0; i <=18; ++i){
				iss >> num;
				b->getTileAt(i)->setResource(numToRsrc(num));
				b->getTileAt(i)->setRoll(x[i]);
			}

			int findNetflix;
			int findseven;
			for (int i = 0; i < 19; i++){
				if (b->getTileAt(i)->getVal() == 7){
					findseven = i;
				}
				if (b->getTileAt(i)->getRes() == 'N'){
					findNetflix = i;
				}
			}
			int tmp = b->getTileAt(findseven)->getVal();
			b->getTileAt(findseven)->setRoll(x[findNetflix]);
			b->getTileAt(findNetflix)->setRoll(tmp);

			iss.clear();

}

void Game::init(){
	srand(s);
	b = new Board;

	Player * p1 = new Player {"Blue"};
	players.emplace_back(p1);
	Player * p2 = new Player {"Red"};
	players.emplace_back(p2);
	Player * p3 = new Player {"Orange"};
	players.emplace_back(p3);
	Player * p4 = new Player {"Yellow"};
	players.emplace_back(p4);

	int x[19];
	x[0] = 2;
	int counter = 1;
	for (int i = 3; i <= 6; i++){
		x[counter] = i;
		x[counter + 1] = i;
		counter += 2;
	}
	for (int i = 8; i <= 11; i++){
		x[counter] = i;
		x[counter + 1] = i;
		counter += 2;
	}
	x[counter] = 12;
	x[counter + 1] = 7;
	random_shuffle(&x[0], &x[19]);

	char R[19];
	R[0] = 'N'; R[1] = 'T'; R[2] = 'T'; R[3] = 'T'; R[4] = 'S'; R[5] = 'S'; R[6] = 'S'; R[7] = 'C'; R[8] = 'C'; R[9] = 'C'; R[10] = 'C'; R[11] = 'L';
	R[12] = 'L'; R[13] = 'L'; R[14] = 'L'; R[15] = 'l'; R[16] = 'l'; R[17] = 'l'; R[18] = 'l';

	random_shuffle(&R[0], &R[19]);
	random_shuffle(&R[0], &R[19]);

	int findNetflix;
	int findseven;
	for (int i = 0; i < 19; i++){
		if (x[i] == 7){
			findseven = i;
		}
		if (R[i] == 'N'){
			findNetflix = i;
		}
	}

	int tmp = x[findseven];
	x[findseven] = x[findNetflix];
	x[findNetflix] = tmp;

	for (int i = 0; i < 19; i++){
		b->getTileAt(i)->setRoll(x[i]);
		b->getTileAt(i)->setResource(R[i]);
	}
	
	b->updateDisplay();
}


void Game::save(int currPlayer, string file){
	ofstream ofs (file);
	ofs << currPlayer << endl;
	for (int i = 0; i <= 3; ++i){
		ofs << players[i]->getResource('C') << " " << players[i]->getResource('L');
		ofs << " " << players[i]->getResource('l') << " " ;
		ofs << players[i]->getResource('S') << " "<< players[i]->getResource('T');
		ofs << " g ";
		ofs << players[i]->saveGoals();
		ofs << "c ";
		ofs << players[i]->saveCriteria();
		ofs << endl;
	}
	for (int i = 0; i <=18; ++i){
		if (b->getTileAt(i)->getRes() == 'C'){
			ofs << 0;
		}
		else if (b->getTileAt(i)->getRes() == 'L'){
			ofs << 1;
		}
		else if (b->getTileAt(i)->getRes() == 'l'){
			ofs << 2;
		}
		else if (b->getTileAt(i)->getRes() == 'S'){
			ofs << 3;
		}
		else if (b->getTileAt(i)->getRes() == 'T'){
			ofs << 4;
		}
		else if (b->getTileAt(i)->getRes() == 'N'){
			ofs << 5;
		}
		ofs << " ";
	}
	ofs.close();
}

char Game::numToRsrc(int n){
	if (n == 0) return 'C';
	if (n == 1) return 'L';
	if (n == 2) return 'l';
	if (n == 3) return 'S';
	if (n == 4) return 'T';
	if (n == 5) return 'N';
}

int Game::load(string fileName){
	srand(s);
	b = new Board;
    ifstream file {fileName};
    string line,s;
    int currTurn;
    int num;
    int lineNum = 1;
    
	while (getline(file, line)) {
    	istringstream iss(line);
    	if (lineNum == 1){
    		iss >> currTurn; 
    	}
		else if (lineNum == 2){
			Player * p = new Player {"Blue"};
			iss >> num;
			p->updateResources('C', num);
			iss >> num;
			p->updateResources('L', num);
			iss >> num;
			p->updateResources('l', num);
			iss >> num;
			p->updateResources('S', num);
			iss >> num;
			p->updateResources('T', num);
			iss >> num;
			p->updateResources('N', num);
			string s;
			iss >> s;
			int num2;
			while(iss >> num){
				p->loadGoals(getGoal(num));
				getGoal(num)->setOwner(p);
			}
			iss.clear();
			iss >> s;
			while (iss >> num){
				iss >> num2;
				bool works = p->completeLoaded(getCriterion(num), num2);
			}
			iss.clear();
			players.emplace_back(p);
		}
		else if (lineNum == 3){
			Player * p = new Player {"Red"};
			iss >> num;
			p->updateResources('C', num);
			iss >> num;
			p->updateResources('L', num);
			iss >> num;
			p->updateResources('l', num);
			iss >> num;
			p->updateResources('S', num);
			iss >> num;
			p->updateResources('T', num);
			iss >> num;
			p->updateResources('N', num);
			string s;
			iss >> s;
			int num2;
			while(iss >> num){
				p->loadGoals(getGoal(num));
				getGoal(num)->setOwner(p);
			}
			iss.clear();
			iss >> s;
			while (iss >> num){
				iss >> num2;
				bool works = p->completeLoaded(getCriterion(num), num2);
			}
			iss.clear();
			players.emplace_back(p);	
		}
		else if (lineNum == 4){
			Player * p = new Player {"Orange"};
			iss >> num;
			p->updateResources('C', num);
			iss >> num;
			p->updateResources('L', num);
			iss >> num;
			p->updateResources('l', num);
			iss >> num;
			p->updateResources('S', num);
			iss >> num;
			p->updateResources('T', num);
			iss >> num;
			p->updateResources('N', num);
			string s;
			iss >> s;
			int num2;

			while(iss >> num){
				p->loadGoals(getGoal(num));
				getGoal(num)->setOwner(p);
			}
			iss.clear();
			iss >> s;
			while (iss >> num){
				iss >> num2;
				bool works = p->completeLoaded(getCriterion(num), num2);
			}
			iss.clear();
			players.emplace_back(p);
		}
		else if (lineNum == 5){
			Player * p = new Player {"Yellow"};
			iss >> num;
			p->updateResources('C', num);
			iss >> num;
			p->updateResources('L', num);
			iss >> num;
			p->updateResources('l', num);
			iss >> num;
			p->updateResources('S', num);
			iss >> num;
			p->updateResources('T', num);
			iss >> num;
			p->updateResources('N', num);

			string s;
			iss >> s;
			int num2;
			while(iss >> num){
				p->loadGoals(getGoal(num));
				getGoal(num)->setOwner(p);
			}
			iss.clear();
			iss >> s;
			while (iss >> num){
				iss >> num2;
				bool works = p->completeLoaded(getCriterion(num), num2);
			}
			iss.clear();
			players.emplace_back(p);
		}
		else if (lineNum == 6){
			int x[19];
			x[0] = 2;
			int counter = 1;
			for (int i = 3; i <= 6; i++){
				x[counter] = i;
				x[counter + 1] = i;
				counter += 2;
			}
			for (int i = 8; i <= 11; i++){
				x[counter] = i;
				x[counter + 1] = i;
				counter += 2;
			}
			x[counter] = 12;
			x[counter + 1] = 7;
			random_shuffle(&x[0], &x[19]);
			// randomly generate values
			// b->getTileAt(i)->setRoll(x[i]); ??

			for (int i = 0; i <=18; ++i){
				iss >> num;
				b->getTileAt(i)->setResource(numToRsrc(num));
				b->getTileAt(i)->setRoll(x[i]);
			}

			int findNetflix;
			int findseven;
			for (int i = 0; i < 19; i++){
				if (b->getTileAt(i)->getVal() == 7){
					findseven = i;
				}
				if (b->getTileAt(i)->getRes() == 'N'){
					findNetflix = i;
				}
			}
			int tmp = b->getTileAt(findseven)->getVal();
			b->getTileAt(findseven)->setRoll(x[findNetflix]);
			b->getTileAt(findNetflix)->setRoll(tmp);
		}
		++lineNum;
	}
	file.close();
	return currTurn;
}

