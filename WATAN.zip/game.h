#ifndef GAME_H
#define GAME_H

#include <string>
#include <vector>
#include "player.h"
#include "board.h"
#include "player.h"
#include "textdisplay.h"

class Board;
   
class Game {
    Board * b;
    std::vector <Player*> players;
    int s = 0;
    bool isLoaded = false;
    bool isBoard = false;
    // Player * curPlayer; // Player who's turn it is
public:
    Game();
    void init(); // initialize a new random game
    Criterion * getCriterion(int pos);
    Goal * getGoal(int pos);
    Player * getPlayer(int i);
    Player * getPlayer(std::string colour);
    void play();

    void save(int currPlayer, std::string file); // save current game
    int load(std::string fname); // load game from file named fname
    void loadBoard(std::string fileName);


    void seed(int s); // sets rng to seed s
    void board(std::string fname); // laods game with board from fname
    void updateDisplay();
    void play(int rollNumber);
    void printBoard();
    void newGame();
    virtual ~Game();
private:
    char numToRsrc(int n);
};

#endif /* GAME_H */

