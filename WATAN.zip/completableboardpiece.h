#ifndef ACHIEVBOARDPIECE_H
#define ACHIEVBOARDPIECE_H
#include "boardpiece.h"

class Player;
class Criterion;
class Goal;

class CompletableBoardPiece : public BoardPiece {
    Player * owner; // plyer who owns this piece, or nullptr if no owner
public:
	bool isOwned();
	bool isOwnedBy(Player *p);
	Player * getOwner();
	void setOwner(Player * p);
	virtual ~CompletableBoardPiece() = 0;
	//virtual void addNghbr(BoardPiece * bp, Type bpt);
    virtual bool complete(Player * p) = 0; // completes goal or course criterion, if player has resources
};

#endif 

