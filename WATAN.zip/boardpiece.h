#ifndef BOARDPIECE_H
#define BOARDPIECE_H
#include "subject.h"
#include "observer.h"
#include "player.h"

class Criterion;
class Goal;

class BoardPiece: public Subject{
	int posn;
	int x, y;
protected:
	std::vector <Criterion*> nghbrCriteria;
    std::vector <Goal*> nghbrGoals;
public:
	virtual ~BoardPiece() = 0;
	//virtual void addNghbr(BoardPiece * bp, Type bpt);
	void addNghbrCriteria(Criterion * bp, Type bpt);
	void addNghbrGoal(Goal * bp, Type bpt);
    void setPosn(int x, int y, int posn);
    int getX();
    int getY();
    int getPosn();
    // void setRoll(int roll);
    //virtual bool complete(Player * p) = 0; // completes goal or course criterion, if player has resources
    //virtual int getBNum() = 0; // returns board position
};

#endif /* BOARDPIECE_H */

