#include <iostream> //
#include <memory>
#include "board.h"
#include "tile.h"
#include "criterion.h"
#include "textdisplay.h"

using namespace std;

Board::Board(){
	td = new TextDisplay();
	init();    
}

void Board::init(){
	setup_tiles();
	setup_criteria();
	setup_goals();
	attachCriteriaToTiles();
	addCriteriaNghbrs();
	addGoalsNghbrs();

}

void Board::updateDisplay(){	
	for (int i = 0; i < numCriteria; i++){
		td->setCriteria(criteria[i].getRepres(), i);
	}
	for (int i = 0; i < numGoals; i++){
		td->setGoals(goals[i].getRepres(), i);
	}

	for (int i = 0; i < numTiles; i++){
		td->setTiles(to_string(i), tiles[i].getRes(), to_string(tiles[i].getVal()), tiles[i].geeseCheck(), i);
	}
}

Board::~Board() {
	delete td;
}

void Board::play(int val){
	for (auto tile : tiles){
		if (tile.getVal() == val){
			tile.play();
		}
	}
}

Tile * Board::getTileAt(int pos){
	return &tiles[pos];
}

Goal * Board::getGoalAt(int pos){
	return &goals[pos];
}

Criterion * Board::getCriterionAt(int pos){
	return &criteria[pos];
}

ostream &operator<<(ostream &out, const Board &b) {
	out <<  *(b.td);
	return out;
}



bool Board::isValidTile(int x, int y){
	if (x == 0 ||  x == 5){
		if (y >= 2 && y <= 6) return true;
	}
	if (x == 1 ||  x == 4){
		if (y >= 1 && y <= 7) return true;
	}
	if (x == 2 ||  x == 3){
		if (y >= 0 && y <= 8) return true;
	}
	return false;
}

bool Board::isValidVertex(int x, int y) {
	if (x == 0 ||  x == 5){
		if (y >= 2 && y <= 8) return true;
	}
	if (x == 1 ||  x == 4){
		if (y >= 1 && y <= 9) return true;
	}
	if (x == 2 ||  x == 3){
		if (y >= 0 && y <= 10) return true;
	}
	return false;	
}

bool Board::isValidHorizEdge(int x, int y){
	if (x == 0 || x == 4){
		if (y >=2 && y <= 8) return true;
	}
	if (x == 1 || x == 3) {
		if (y >= 1 && y <= 9) return true;
	}
	if (x == 2){
		if (y >= 0 && y <= 10) return true;
	}
	return false;
}

bool Board::isValidVertEdge(int x, int y){
	if (x == 0 ||  x == 5){
		if (y >= 2 && y <= 7) return true;
	}
	if (x == 1 ||  x == 4){
		if (y >= 1 && y <= 8) return true;
	}
	if (x == 2 ||  x == 3){
		if (y >= 0 && y <= 9) return true;
	}
	return false;	
}

void Board::setup_tiles(){
	tiles = vector <Tile> (numTiles);
	int index = 0;
	for (int j = 0; j <= 2*size - 2; ++j){
		int i = ( j % 2 != 0 ) ? 1 : 0;
		for ( ; i <= size - 1; i += 2){
			if (isValidTile (i,j)) {
				tiles[index].setPosn(i,j,index);
				tiles[index].attach(td);
				++index;
			} 
		}
	}
}

void Board::setup_criteria(){
	criterionGrid = vector<vector<Criterion*>> (size + 1, vector<Criterion*>(2*size+1,nullptr));
	criteria = vector <Criterion> (numCriteria);
	int index = 0;
	for (int j = 0; j <= 2*size; ++j){
		for (int i = 0 ; i <= size; ++i){
			if (isValidVertex(i,j)){
				criteria[index].setPosn(i,j,index);
				criteria[index].attach(td);
				criterionGrid[i][j] = &criteria[index];
				++index;
			}
		}
	}
}

void Board::setup_goals(){
	horizGoalGrid = vector<vector<Goal*>> (size + 1, vector<Goal*>(2*size+1,nullptr));
	vertGoalGrid = vector<vector<Goal*>> (size + 1, vector<Goal*>(2*size+1,nullptr));
	goals = vector <Goal> (numGoals);
	int index = 0;
	
	for (int j = 0; j <= 2*size; ++j){
		int i = ( j % 2 != 0 ) ? 1 : 0;
		for ( ; i <= size-1; i += 2){
			if (isValidHorizEdge(i,j)){
				goals[index].setPosn(i,j,index);
				goals[index].setIsHoriz(true);
				goals[index].attach(td);
				horizGoalGrid[i][j] = &goals[index];
				++index;
			}
		}

		for (int i = 0 ; i <= size; ++i){
			if (isValidVertEdge(i,j)){
				goals[index].setPosn(i,j,index);
				goals[index].setIsHoriz(false);
				goals[index].attach(td);
				vertGoalGrid[i][j] = &goals[index];
				++index;
			}
		}
	}
}

void Board::attachCriteriaToTiles(){
	for (auto & tile : tiles){
		int x = tile.getX();
		int y = tile.getY();
		tile.addNghbrCriteria(criterionGrid[x][y], Type::Criterion);
		tile.addNghbrCriteria(criterionGrid[x][y+1], Type::Criterion);
		tile.addNghbrCriteria(criterionGrid[x][y+2], Type::Criterion);
		tile.addNghbrCriteria(criterionGrid[x+1][y], Type::Criterion);
		tile.addNghbrCriteria(criterionGrid[x+1][y+1], Type::Criterion);
		tile.addNghbrCriteria(criterionGrid[x+1][y+2], Type::Criterion);
		/*
		tile.attach(criterionGrid[x][y]);
		tile.attach(criterionGrid[x][y+1]);
		tile.attach(criterionGrid[x][y+2]);
		tile.attach(criterionGrid[x+1][y]);
		tile.attach(criterionGrid[x+1][y+1]);
		tile.attach(criterionGrid[x+1][y+2]);
		*/
	}
}

void Board::addCriteriaNghbrs(){
	for (auto & crit : criteria){
		int x = crit.getX();
		int y = crit.getY();
		// Adding the neighbouring criteria

		if (isValidVertex(x, y+1)) {
			crit.addNghbrCriteria(criterionGrid[x][y+1], Type::Criterion);
		}
		if (isValidVertex(x, y-1)) {
			crit.addNghbrCriteria(criterionGrid[x][y-1], Type::Criterion);
		}

		int x2;
		if ((x%2 == 0 && y%2 == 0) || (x%2 != 0 && y%2 != 0)) {
			x2 = x+1; 
		} else{
			x2 = x-1;
		}if (isValidVertex(x2,y)) {
			crit.addNghbrCriteria(criterionGrid[x2][y], Type::Criterion);
		}

		// Adding the neigbouring goals
		if (isValidHorizEdge(x,y) && horizGoalGrid[x][y] != nullptr){
			crit.addNghbrGoal(horizGoalGrid[x][y], Type::Goal);
		}
		if (isValidHorizEdge(x-1,y) && horizGoalGrid[x-1][y] != nullptr){
			crit.addNghbrGoal(horizGoalGrid[x-1][y], Type::Goal);
		}
		if (isValidVertEdge(x,y) && vertGoalGrid[x][y] != nullptr){
			crit.addNghbrGoal(vertGoalGrid[x][y], Type::Goal);
		}
		if (isValidVertEdge(x,y-1) && vertGoalGrid[x][y-1] != nullptr){
			crit.addNghbrGoal(vertGoalGrid[x][y-1], Type::Goal);
		}
	}
}


void Board::addGoalsNghbrs(){
	for (auto & goal : goals){
		int x = goal.getX();
		int y = goal.getY();
		bool isHoriz = goal.isItHoriz();
		//Adds the neigbouring Criteria

		if (isValidVertex(x,y)){
			goal.addNghbrCriteria(criterionGrid[x][y], Type::Criterion);
		}
		if (isHoriz && isValidVertex(x+1,y)){
			goal.addNghbrCriteria(criterionGrid[x+1][y], Type::Criterion);
		}else if (!isHoriz && isValidVertex(x,y-1)){
			goal.addNghbrCriteria(criterionGrid[x][y-1], Type::Criterion);
		}

		//Add the neigbouring goals
		if (isHoriz){
			if (isValidVertEdge(x,y)){
				goal.addNghbrGoal(vertGoalGrid[x][y], Type::Goal);
			}
			if (isValidVertEdge(x+1,y)){
				goal.addNghbrGoal(vertGoalGrid[x+1][y], Type::Goal);
			}
			if (isValidVertEdge(x+1,y-1)){
				goal.addNghbrGoal(vertGoalGrid[x+1][y-1], Type::Goal);
			}
			if (isValidVertEdge(x,y-1)){
				goal.addNghbrGoal(vertGoalGrid[x][y-1], Type::Goal);
			}
		}

		else if (!isHoriz){ 
			if (isValidVertEdge(x,y-1)){
				goal.addNghbrGoal(vertGoalGrid[x][y-1], Type::Goal);
			}
			if (isValidVertEdge(x,y+1)){
				goal.addNghbrGoal(vertGoalGrid[x][y+1], Type::Goal);
			}

			if ((x%2 == 0 && y%2 == 0) || (x%2 != 0 && y%2 != 0)) {
				if (isValidHorizEdge(x,y)){
					goal.addNghbrGoal(horizGoalGrid[x][y], Type::Goal);
				}
				if (isValidHorizEdge(x-1,y+1)){
					goal.addNghbrGoal(horizGoalGrid[x-1][y+1], Type::Goal);
				}
			}
			else {
				if (isValidHorizEdge(x,y+1)){
					goal.addNghbrGoal(horizGoalGrid[x][y+1], Type::Goal);
				}
				if (isValidHorizEdge(x-1,y)){
					goal.addNghbrGoal(horizGoalGrid[x-1][y], Type::Goal);
				}
			}
		}
	}
}
