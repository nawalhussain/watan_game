#include <iostream>
#include "vertex.h"
using namespace std;


Vertex::~Vertex() {
}

