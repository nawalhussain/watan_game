#ifndef BOARD_H
#define BOARD_H
#include <vector>
#include <memory>
#include <string>
#include "tile.h"
#include "criterion.h"
#include "goal.h"
#include "textdisplay.h"


class Board {
    TextDisplay * td;
    const int numTiles = 19;
    const int numCriteria = 54;
    const int numGoals = 72;
    const int size = 5;  // for grid repr
	void setup_tiles();
	void setup_criteria();
    void setup_goals();
    std::vector<Tile> tiles;
	std::vector <Criterion> criteria;
    std::vector <Goal> goals;
    std::vector <std::vector <Criterion*>> criterionGrid;
    std::vector <std::vector <Goal*>> horizGoalGrid;
    std::vector <std::vector <Goal*>> vertGoalGrid;
private:
    bool isValidTile(int x, int y);
    bool isValidVertex(int x, int y);
    bool isValidHorizEdge(int x, int y);
    bool isValidVertEdge(int x, int y);
    void attachCriteriaToTiles();
    void addCriteriaNghbrs();
    void addGoalsNghbrs();
public:
    Board();
    virtual ~Board();
    Tile * getTileAt(int pos);
    Goal * getGoalAt(int pos);
    Criterion * getCriterionAt(int pos);
    void updateDisplay();
    void draw(); // draws current board to screen
    void init(); // initializes new board ??
    void play(int val);
    friend std::ostream &operator<<(std::ostream &out, const Board &b);
};

#endif /* BOARD_H */

