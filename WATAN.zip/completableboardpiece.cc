#include "completableboardpiece.h"


CompletableBoardPiece::~CompletableBoardPiece() {}

void CompletableBoardPiece::setOwner(Player * p){
	owner = p;
}

bool CompletableBoardPiece::isOwned(){
	if (owner == nullptr) return false;
	return true;
}

Player * CompletableBoardPiece::getOwner(){
	return owner;
}

bool CompletableBoardPiece::isOwnedBy(Player *p){
	if (owner == p) return true;
	else return false;
}

//virtual bool complete(Player * p) = 0; // completes goal or course criterion, if player has resources
