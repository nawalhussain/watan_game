#ifndef _BPTYPE_H_
#define _BPTYPE_H_
enum class Type { Criterion, Tile, Goal, Display};
#endif
