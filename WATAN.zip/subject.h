#ifndef _SUBJECT_H_
#define _SUBJECT_H_
#include <vector>
#include <string>
#include <memory>
#include "types.h"
#include "textdisplay.h" //
class Info;
class Observer;

class Subject {
	std::vector<Observer*> observers;
public:
	virtual ~Subject() = 0;
  	void attach(Observer * o);  
  	void notifyObservers(Type t);
  	//virtual Type getType() = 0 ;

	//virtual std::string getInfo() = 0;

  
};

#endif
