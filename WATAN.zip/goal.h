#ifndef GOAL_H
#define GOAL_H

#include "types.h"
#include "edge.h"

class Goal : public Edge {
	std::string repres;
public:
    Goal();
    virtual ~Goal();
    Type getType() const;
    bool complete(Player *p) ;
    std::string getRepres();
private:
	bool isAchievable(Player *p);
	bool enoughResources(Player * p);
};

#endif /* GOAL_H */

