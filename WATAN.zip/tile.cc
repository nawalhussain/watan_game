#include <iostream>
#include <vector>
#include <string.h>
#include "criterion.h"
#include "tile.h"

using namespace std;


Tile::Tile(){
}

Tile::~Tile() {
}

Type Tile::getType() const {
	return Type::Tile;
}

bool Tile::geeseCheck(){
	return isGeese;
}

char Tile::getRes(){
	return resource;
}

int Tile::getVal(){
	return rollVal;
}

void Tile::setRoll(int roll){
	rollVal = roll;
}

void Tile::setResource(char c){
	resource = c;
}

void Tile::play(){
	for(auto crit : nghbrCriteria){
		crit->give(resource);
	}
}
