#include <string>
#include <sstream>
#include "goal.h"
#include "criterion.h"
using namespace std;

Goal::Goal() {
	setOwner(nullptr);
}

Goal::~Goal() {
}

bool Goal::enoughResources(Player * p){
	if ((p->getResource('S') >= 1) && (p->getResource('T') >= 1)) {
		return true;
	}
	return false;
}

bool Goal::isAchievable(Player * p){
	if (!this->isOwned()) {
		for(auto crit : nghbrCriteria){
			if (crit->isOwnedBy(p)){
				return true;
			}
		}
		for (auto goal : nghbrGoals){
			if (goal->isOwnedBy(p)){
				return true;
			}
		}
	}
	return false;
}

bool Goal::complete(Player *p) {
	if (isAchievable(p)) {
		if (enoughResources(p)){
			setOwner(p);
			p->updateResources('S', -1);
			p->updateResources('T', -1);
			return true;
		}
		cout << "You do not have enough resources." << endl;
		return false;
	}
	cout << "You cannot build here." << endl;
	return false;
}

Type Goal::getType() const {
  return Type::Goal;
}

string Goal::getRepres() {
	stringstream ss;
	if (!isOwned()){
		return to_string(getPosn());
	}else{
		ss << getOwner()->getColour()[0] << "A";
		return ss.str();
	}
}




/*
void Goal::addNghbr(BoardPiece * bp, Type bpt){
	if (bpt == Type::Criterion){
		nghbrCriteria.emplace_back(bp);
	}
	else if (bpt == Type::Goal){
		nghbrGoals.emplace_back(bp);
	}
}
*/
