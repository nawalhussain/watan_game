#include "boardpiece.h"


BoardPiece::~BoardPiece() {
}

void BoardPiece::setPosn(int x, int y, int posn){
	this->x = x;
	this->y = y;
	this->posn = posn;
}

int BoardPiece::getX(){
	return x;
}

int BoardPiece::getY(){
	return y;
}
int BoardPiece::getPosn(){
	return posn;
}

void BoardPiece::addNghbrCriteria(Criterion * bp, Type bpt){
		nghbrCriteria.emplace_back(bp);
}

void BoardPiece::addNghbrGoal(Goal * bp, Type bpt){
		nghbrGoals.emplace_back(bp);
}



/*
void BoardPiece::addNghbr(BoardPiece * bp, Type bpt){
	if (bpt == Type::Criterion){
		nghbrCriteria.emplace_back(bp);
	}
	else if (bpt == Type::Goal){
		nghbrGoals.emplace_back(bp);
	}
}
*/
